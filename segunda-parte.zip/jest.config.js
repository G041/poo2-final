module.exports = {
    setupFilesAfterEnv: ['./jest.setup.js'],
};